﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace WpfApp1.Models
{
    public class User
    {
        public string FullName { get; set; }
        public bool IsAdmin { get; set; }
        public Dictionary<string,Task> tasks { get; set; }
    }
}
