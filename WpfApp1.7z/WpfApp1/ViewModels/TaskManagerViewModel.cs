﻿using Firebase.Auth;
using Firebase.Database;
using Firebase.Database.Query;
using MVVMEssentials.Services;
using MVVMEssentials.ViewModels;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Collections.ObjectModel;
using System.Linq;
using System.Numerics;
using System.Reactive.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation.Peers;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Threading;
using WpfApp1.Commands;
using WpfApp1.Models;

namespace WpfApp1.ViewModels
{
    public class TaskManagerViewModel : ViewModelBase
    {
        public static FirebaseClient firebase = new FirebaseClient("https://user-tasks-b8522-default-rtdb.firebaseio.com/");

        public ObservableCollection<Models.Task> tasks { get; set; }

        public string _selectedWorker { get; set; }

        public string _selectedDateSort { get; set; }

     

        public bool IsComplete { get; set; }

        public Dispatcher _dispatcher = Dispatcher.CurrentDispatcher;

        public List<string> _workers { get; set; } = new List<string>();

        public List<string> _dateSort { get; set;} = new List<string>() {"Сбросить","По возрастанию","По убыванию"};

        public TaskManagerCommand FilterByFullName { get; set; }

        public TaskManagerCommand SortByDate { get; set; }

        public TaskManagerCommand IsCompleteFilter { get; set; }

        public TaskManagerCommand FinalStatus { get; set; }

        public TaskManagerCommand PerformedStatus { get; set; }

        public TaskManagerViewModel()
        {
            

            _workers.Add("Сбросить");
            tasks = new ObservableCollection<Models.Task>();
             

            var users = firebase.Child("users").AsObservable<Models.User>().Subscribe(data =>
            {
                
                
                
                _dispatcher.Invoke(new Action(() =>
                {
                    
                    foreach (var pair in data.Object.tasks)
                    {
                        
                        if (!string.IsNullOrWhiteSpace(pair.Value.title) && !string.IsNullOrWhiteSpace(pair.Value.DateOfCompletion) && !string.IsNullOrWhiteSpace(pair.Value.status))
                        {

                            
                            pair.Value.taskId = pair.Key;
                            pair.Value.user = data.Object;
                            pair.Value.UID = data.Key;
                            if(tasks.Contains(pair.Value))
                            {
                                tasks.Remove(pair.Value);
                            }
                            
                            tasks.Add(pair.Value);
                            
                            if (!_workers.Contains(pair.Value.user.FullName))
                            {
                               
                                _workers.Add(pair.Value.user.FullName);

                            }
                        }
                    }

                }));

                
            });

            FilterByFullName = new TaskManagerCommand(obj =>

            {
                if(_selectedWorker!="Сбросить")
                {
                    ApplyFilters();
                }
                
            });
            IsCompleteFilter = new TaskManagerCommand(obj =>
            {

                ApplyFilters();
            });
            SortByDate = new TaskManagerCommand(obj =>

            {
                if (_selectedDateSort != "Сбросить")
                {
                    ApplyFilters();
                }


            });
            FinalStatus = new TaskManagerCommand(ButtonClick);
            PerformedStatus = new TaskManagerCommand(ButtonClick_PerformedStatus);
            


        }
        private async void ButtonClick (object parameter)
        {
            var itemTask = parameter as Models.Task;
            itemTask.status = "Завершено";
            await firebase.Child("users").Child(itemTask.UID).Child("tasks").Child(itemTask.taskId).PutAsync(itemTask);
        }

        private async void ButtonClick_PerformedStatus (object parameter)
        {
            var itemTask = parameter as Models.Task;
            itemTask.status = "Выполняется";
            await firebase.Child("users").Child(itemTask.UID).Child("tasks").Child(itemTask.taskId).PutAsync(itemTask);
        }
        public void ApplyFilters()
        {

           


        }
       
    }
}
