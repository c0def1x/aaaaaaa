﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace WpfApp1.Converters
{
    public class StringToBooleanConverter :IValueConverter
    {
        public object Convert (object value, Type targetType, object parameter, CultureInfo culture)
        {
            switch ((string) value)
            {
                case "Выполнено":
                    return Visibility.Visible;
                case "Выполняется":
                    return Visibility.Collapsed;
                case "Завершено":
                    return Visibility.Collapsed;
            }
            return false;
        }

        public object ConvertBack (object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
